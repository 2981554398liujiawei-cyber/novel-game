# R2 状态与 Manager 映射

## QuestManager

任务：
- NV_MAIN_005
- NV_MAIN_006
- NV_MAIN_007
- NV_MAIN_008
- NV_HIDDEN_FIND_LIFENGXING

负责：
- 任务阶段
- 任务奖励幂等结算
- 战斗标签转剧情结果
- 九坛泉水交付数量与分配上下文
- 区域完成

## InventoryManager

以下全部为建议ID，登记前均为 proposed_item_id：

- `eq_greed_ring`
- `quest_two_gate_rubbing`
- `tool_chain_breaker`
- `consumable_purification_powder`
- `eq_vajra_greatshield_core`
- `armor_warbear_shell`
- `material_millennium_bear_gall`
- `quest_unclean_tianshu_water`
- `quest_eagle_medal`
- `quest_lifire_core`
- `quest_frost_core`

规则：
- 不使用 `item.xxx = true`
- 九坛泉水为数量型任务物
- 贪婪之戒有鉴定状态
- 高阶奖励必须经过Item Schema注册

## RelationshipManager

仅允许：
- trust
- affection
- respect
- tension

本轮主要关系：
- rel_lanyin_fengyue
- rel_guchangchuan_fengyue
- rel_wangwu_fengyue
- rel_tianhuolenghun_fengyue
- rel_fengyun_group_fengyue

可用flag：
- owes_fengyue_rescue
- cautious_about_fengyue
- avoids_spring_water_topic
- admitted_profit_motive
- lied_about_spring_water

## CombatRunner

建议结果标签：
- cave_mouse_win
- cave_mouse_defeat
- cave_collapse_full
- cave_collapse_partial
- chalala_purified
- chalala_killed
- chalala_injured_escape
- chalala_party_defeat

CombatRunner只返回结果，不直接写关系、物品、任务。

## GameState长期状态

- `world.nv7.two_gate_structure_confirmed`
- `world.nv7.cave_outcome`
- `world.nv7.monster_manipulation_chain_confirmed`
- `world.nv7.chalala_outcome`
- `world.nv7.world_gate_ready`
- `world.nv7.world_gate_open`
- `world.nv7.completed`
- `world.return_channel_status`
- `world.return_lock_source`
- `main_goal.trace_return_authority`

不进入GameState：
- 九坛水具体背包数量
- 贪婪之戒是否装备
- 哪件装备已鉴定
- 某次关系加减
这些分别归InventoryManager与RelationshipManager。
