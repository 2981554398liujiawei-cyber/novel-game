# R1 状态与 Manager 映射

## 1. QuestManager

负责：
- NV_MAIN_001—004 的任务阶段
- NV_MAIN_002 三个并行委托的完成判断
- 任意两项委托完成后首次触发 NV_MAIN_003
- 所有任务奖励幂等结算
- 战斗结果标签转任务阶段
- 任务物品的发放与回收调用

禁止：
- 使用 `quest.NV_MAIN_001 = completed` 之类 GameState 键
- 使用 `commission.completed_count += 1`

建议任务 ID：
- `NV_MAIN_001`
- `NV_MAIN_002`
- `NV_COMMISSION_HANSHI`
- `NV_COMMISSION_SUZHI`
- `NV_COMMISSION_GUCHANGCHUAN`
- `NV_MAIN_003`
- `NV_MAIN_004`

## 2. InventoryManager

建议物品注册（均为 proposed_item_id，登记前不得视为正式 ID）：
- `proposed_item_id:wpn_novice_thin_sword`
- `proposed_item_id:offhand_novice_ironwood_shield`
- `proposed_item_id:wpn_novice_hook_staff`
- `proposed_item_id:quest_sample_blue_powder`
- `proposed_item_id:quest_old_boundary_rubbing`
- `proposed_item_id:eq_mask_dudu_rabbit`
- `proposed_item_id:quest_live_capture_ledger`
- `proposed_item_id:quest_treasure_map_fragment`
- `proposed_item_id:quest_silverblack_fragment`

规则：
- 任务奖励由 QuestManager 调用 InventoryManager 幂等发放。
- 不使用 `item.xxx = true`。
- 临时任务样本在任务结束后可由 QuestManager 消耗。
- 藏宝图只保存一份逻辑物品，通过任务共享权限决定队伍是否可读取。

## 3. RelationshipManager

正式数值维度仅允许：
- `trust`
- `affection`
- `respect`
- `tension`

建议 relationship_id：
- `rel_guchangchuan_fengyue`
- `rel_suzhi_fengyue`
- `rel_hanshi_fengyue`
- `rel_lanyin_fengyue`
- `rel_tianhuolenghun_fengyue`
- `rel_fengyun_group_fengyue`

关系 flag/tag 用于表达非数值语义，例如：
- `owes_fengyue_rescue`
- `cautious_about_fengyue`
- `values_fengyue_pragmatism`
- `remembers_fengyue_candor`

示例效果：
- 保护兔群：`rel_lanyin_fengyue.trust +2`
- 猎杀兔王并坦白收益动机：`rel_lanyin_fengyue.respect +1`
- 猎杀后伪装成“别无选择”：`trust -1`，`tension +1`
- 救天火冷魂：`respect +1`，flag `owes_fengyue_rescue`
- 黄虎被救：风云组 `respect +1`，flag `owes_fengyue_rescue`
- 公开共享藏宝坐标：岚音 `trust +1`

禁止：
- `candor`
- `wariness`
- `debt`
- `pragmatism`
- `closeness`
- `caution`
等任何未注册数值维度。

## 4. CombatRunner

只返回结果标签，不写任务、关系、物品。

建议标签：
- `grey_badger_win`
- `grey_badger_avoid`
- `rabbit_event_protect_success`
- `rabbit_event_protect_partial`
- `rabbit_king_killed`
- `rabbit_event_defeat`
- `spine_rescue_success`
- `wolf_battle_controlled`
- `wolf_battle_killed`
- `wolf_battle_escaped`
- `wolf_battle_defeat`

QuestManager 收到标签后执行：
1. 更新任务阶段
2. 调用 RelationshipManager
3. 调用 InventoryManager
4. 必要时写长期 GameState

## 5. GameState 长期状态

仅保留跨任务、跨区域需要读取的世界结果：

- `world.nv7.rabbit_king_outcome`
  - alive
  - injured
  - dead
- `world.nv7.rabbit_herd_outcome`
  - escaped
  - scattered
  - displaced
- `world.nv7.live_capture_evidence`
  - none
  - confirmed_local_operation
  - ledger_partial
  - ledger_full
- `world.nv7.wolf_king_outcome`
  - controlled
  - escaped
  - dead
- `world.nv7.wangwu_injury_stage`
  - none
  - light
  - medium
- `world.nv7.fengyun_relation_stage`
  - hostile
  - wary
  - temporary_coop
- `world.nv7.adventurers_trapped_confirmed`
  - true / false

不建议长期保存：
- 是否点过菜单空白
- 是否掐过手臂
- 三委托完成数量
- 蓝粉样本是否在背包
- 某句对白是否看过
这些由任务上下文或 SaveManager 的任务快照处理。

## 6. SaveManager

必须保存：
- QuestManager 当前任务阶段
- InventoryManager 任务物品
- RelationshipManager 关系维度
- GameState 长期世界结果
- CombatRunner 战败后续接节点

读档必须允许玩家查看不同选择，但每个存档内部不得把战败自动恢复成“从未发生”。
